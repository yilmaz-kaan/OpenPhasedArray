G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2026-03-27T16:33:29-05:00*
G04 #@! TF.ProjectId,FiniteAntennaPatch,46696e69-7465-4416-9e74-656e6e615061,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2026-03-27 16:33:29*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G36*
X38240000Y-48160000D02*
G01*
X263240000Y-48160000D01*
X263240000Y-128160000D01*
X38240000Y-128160000D01*
X38240000Y-48160000D01*
G37*
M02*
